/********************************************SERVER & HOST CODE**********************************************************/
/*
 * Name : Samarth Rajendra Sangar.
 * Date : 14/11/2024
 * Project Name : PICK TO LIGHT
 *                This code contains server & host part of project.In this project 
 *                transfer data from tara term using UART & transfer to client part 
 *                using CAN Bus that are done.
 */
#include <xc.h>
#include "main.h"
#include "uart.h"
#include "can_1_1.h"

/*Variables & flag's to check condition's*/
unsigned char ch='\0';
unsigned int stock_count,Product_id,receive_flag,Receive_flag=0;
unsigned int Flag=0,Change_flag=0;

/*Initial configurtion function*/
void init_config(void)
{
	init_uart();            //function call to set configuration of UART
    init_can();             //function call to set configuration of CAN Bus
	 /* Enabling peripheral interrupt */
   PEIE = 1;
    
    /* Enabling global interrupt */
   GIE = 1;
}
/*Main function*/
void main()
{
	init_config();              //function call for initial configuration
    unsigned int temp_P_ID=0,temp_U_ST=0;

	while (1)                   //continuous loop
	{
            if(Flag==1)         //check flag & print message on Tara term
            {
                temp_P_ID=0,temp_U_ST=0;
                puts("\n\rEnter the P_ID [Max 4 byte] : ");
                Flag=3;
            }
            else if(Flag==2)
            {
                puts("\n\rEnter the U_ST [Max 4 byte] : ");
                Flag=4;
                Change_flag=2;
            }
        if(can_receive())               //check data received or not
        {
            Flag=0;                     //if received change flag's
            Change_flag=0;
            Receive_flag=0;
            puts("\n\rDATA RECEIVED -->\n\rU_ST : ");       //print the information on tara term
            putch(can_payload[D0]+48);
            putch(can_payload[D1]+48);
            putch(can_payload[D2]+48);
            putch(can_payload[D3]+48);
            
            puts("\n\rP_ID : ");
            putch(can_payload[D4]+48);
            putch(can_payload[D5]+48);
            putch(can_payload[D6]+48);
            putch(can_payload[D7]+48);
            puts("\n\n\r");
        }
            
        if(ch!='\0' && (ch!=13 && ch!='\n'))        //take one one byte data from tara term
        {
            putch(ch);
            
            if(Change_flag==1)
            {
                if((ch>='0'&& ch<='9'))             //only number data add
                {
                    temp_P_ID=((temp_P_ID*10)+(ch-48));
                    if(temp_P_ID>=10000)            //if more then four byte then remove 1 
                    {
                       temp_P_ID/=10;
                    }
                }
            }
            else if(Change_flag==2)                //take data for user stock
            {
                if((ch>='0'&&ch<='9'))              //only number data add
                {
                   temp_U_ST=((temp_U_ST*10)+(ch-48));
                   if(temp_U_ST>=10000)             //if more then four byte then remove 1 
                   {
                        temp_U_ST/=10;
                   }
                }
            }
            ch='\0';
        }
        else if(ch!='\0' && (ch=='\r' || ch=='\n'))     //if first time enter then take value for user interaction
        {
            Change_flag++;
            Flag++;
            if(Change_flag==2)                      //check flag & set another flag
            {
                Flag=2;
            }
            if(Change_flag>=3)                      //check flag & transmit the data
            {
                Product_id=temp_P_ID;
                stock_count=temp_U_ST;
                can_transmit();
                puts("\n\r");
                Change_flag=1;
                Flag=1;
                temp_P_ID=0,temp_U_ST=0;
            }
            ch='\0';                                //add null in character
        }		
	}
}
