#include <xc.h>
/*Externally connect variable for character store*/
extern unsigned char ch;
void __interrupt() isr(void)
{
    if (RCIF == 1)
    {
        if (OERR == 1)
            OERR = 0;
        
        ch = RCREG;         //store character in varibles
        
        RCIF = 0;           //make flag zero
    }
}
