#include <xc.h>
#include "isr.h"
#include "ssd.h"

/*Externally connected varible*/
extern unsigned int key_detected;

void __interrupt() isr(void)
{
	if (INT0F == 1)
	{
        if(key_detected==0)
        {
            for(int delay=0; delay<=200; delay++);    //Make some delay & change value of variables
            key_detected=1;
        }
        else
        {
            for(int delay=0; delay<=200; delay++);     //Make some delay & change value of variables
            key_detected=0;
        }
            
		INT0F = 0;                                      //make flag zero
	}
}
