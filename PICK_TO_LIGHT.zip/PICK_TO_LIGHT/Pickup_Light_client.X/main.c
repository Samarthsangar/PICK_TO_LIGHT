/********************************************CLIENT SIDE CODE**********************************************************/
/*
 * Name : Samarth Rajendra Sangar.
 * Date : 14/11/2024
 * Project Name : PICK TO LIGHT
 *                This code contains Client part of project.In this project 
 *                Receive the data from server & checking the P_ID if correct then 
 *                print SSD are done After saving the data transfer to server for
 *                printing using CAN Bus.
 */
#include <xc.h>
#include "main.h"
#include "external_interrupt.h"
#include "isr.h"
#include "ssd.h"
#include "Keypad.h"
#include "eeprom.h"
#include "can_1.h"

/*character array for SSD*/
unsigned char ssd[MAX_SSD_CNT];
unsigned int stock_count,Product_id;
/*character array for digits increments*/
static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, UNDERSCORE, U, T, P,D};
/*variables for SSD and delay & condition chceking*/
int i = 0, j = 0, k = 0, l = 0,sec=0;
/*Flag's variables to check conditions*/
unsigned int key_detected=1,key=0,Flag1=0,Change_field=0;

/*Receive function if data received*/
void Can_Receive_Save()
{
    /*Initial set all flag's*/
    unsigned int Change_Flag=1;
    unsigned short Change_Mode=1;
    Flag1=0;
    
    /*Read received stock data & assign to the SSD*/
    unsigned int d=can_payload[D3];
    unsigned int c=can_payload[D2];
    unsigned int b=can_payload[D1];
    unsigned int a=can_payload[D0];
    ssd[0] = digit[a];
    ssd[1] = digit[b];
    ssd[2] = digit[c];
    ssd[3] = digit[d];
    while(1)                            //Continuous super loop
    {
        if(key_detected==1)             //Check detect interrupt or not
        {
            if(Change_Flag==1)          //if interrupt come then Update SSD
            {
                ssd[3] = T;
                ssd[2] = FIVE;
                ssd[1] = UNDERSCORE;
                ssd[0] = U;
            }
            key=read_digital_keypad(STATE_CHANGE);      //Read status of switches
            if(key==SWITCH3)                            //based on switch value update the flag & SSD
            {
                Change_Flag++;
                if(Change_Flag==2)
                {
                    ssd[3] = D;
                    ssd[2] = ONE;
                    ssd[1] = UNDERSCORE;
                    ssd[0] = P;
                }
                else
                {
                    Change_Flag=1;
                    ssd[3] = T;
                    ssd[2] = FIVE;
                    ssd[1] = UNDERSCORE;
                    ssd[0] = U;
                }
            }
            else if(key==SWITCH2)                       //if switch2 pressed inter into particular event
            {
                key_detected=0;
                Change_field=1;
                if(Change_Flag==1)
                    User_Stock();
                else
                    Product_ID();
                
                if(Change_field==1)                             //check flag to print received stock data
                {
                    key_detected=0;
                    ssd[0] = digit[a];
                    ssd[1] = digit[b];
                    ssd[2] = digit[c];
                    ssd[3] = digit[d];
                }
                else                                            //else update flag & return
                {
                    key_detected=1;
                    Change_field=0;
                    ssd[3] = T;
                    ssd[2] = FIVE;
                    ssd[1] = UNDERSCORE;
                    ssd[0] = U;
                    return;
                }  
            }
        }
        else                                    //else do increment decrement  the value of received stock
        {
            key=read_digital_keypad(STATE_CHANGE);      //Based on switch pressed increment &  decrement
            
            if(key==SWITCH1)        //switch1 then increment
            {
                if(d++>=9)
                {
                    d=0;
                    if(c++>=9)
                    {
                        c=0;
                        if(b++>=9)
                        {
                            b=0;
                            if(a++>=9)
                            {
                                a=0;
                                b=0;
                                c=0;
                                d=0;
                            }
                        }
                    }
                }
                ssd[0] = digit[a];
                ssd[1] = digit[b];
                ssd[2] = digit[c];
                ssd[3] = digit[d];
            }
            else if(key==SWITCH2)               //switch2 then decrement
            {
                if(d--<=0)
                {
                    d=9;
                    if(c--<=0)
                    {
                        c=9;
                        if(b--<=0)
                        {
                            b=9;
                            if(a--<=0)
                            {
                                a=9;
                                b=9;
                                c=9;
                                d=9;
                            }
                        }
                    }
                }
                ssd[0] = digit[a];
                ssd[1] = digit[b];
                ssd[2] = digit[c];
                ssd[3] = digit[d];
            }
            
            if(key==SWITCH3)                        //If switch3 then update value in EEPROM & transmit to server
            {
                stock_count=((((((a*10)+b)*10)+c)*10)+d);
                write_internal_eeprom(0x00, d);          
                write_internal_eeprom(0x01, c);
                write_internal_eeprom(0x02, b);
                write_internal_eeprom(0x03, a);
                key_detected=1;
                Change_field=0;
                can_transmit();
                ssd[3] = T;
                ssd[2] = FIVE;
                ssd[1] = UNDERSCORE;
                ssd[0] = U;
                return;
            }   
        }
        display(ssd);               //Display Data in SSD
    }
}
/*function for product ID*/
void Product_ID()
{
    /*Read the data from EEPROM*/
    Product_id=(read_internal_eeprom(0x04))+(read_internal_eeprom(0x05)*10)+(read_internal_eeprom(0x06)*100)+(read_internal_eeprom(0x07)*1000);
    i=(Product_id%10);              //Storing 1-1 byte in variables
    j=((Product_id/10)%10);
    k=((Product_id/100)%10);
    l=(Product_id/1000);
    ssd[0] = digit[l];              //Update SSD data to print & display
    ssd[1] = digit[k];
    ssd[2] = digit[j];
    ssd[3] = digit[i]|0x10;
    display(ssd);
    SSD_PRINT_DATA(2);              //function call
}
/*User stock function*/
void User_Stock()
{   
    /*Read the data from EEPROM*/
    stock_count=(read_internal_eeprom(0x00))+(read_internal_eeprom(0x01)*10)+(read_internal_eeprom(0x02)*100)+(read_internal_eeprom(0x03)*1000);
    i=(stock_count%10);             //Storing 1-1 byte in variables
    j=((stock_count/10)%10);
    k=((stock_count/100)%10);
    l=(stock_count/1000);
    ssd[0] = digit[l];              //Update SSD data to print & display
    ssd[1] = digit[k];
    ssd[2] = digit[j];
    ssd[3] = digit[i]|0x10;
    display(ssd);
    SSD_PRINT_DATA(1);              //function call
}
/*Function for changes Data & print on SSD*/
void SSD_PRINT_DATA(int Operation)
{
    unsigned short Change_Mode=1;
    while(1)                        //continuous loop
    {
        if(can_receive())           //Check any other data is received or not
        {
            Flag1=1;                //if yes then set flag1 & return
            key_detected=0;
            return;
        }
        
        if(key_detected==1)             //check status of interrupt switch
        {
            if(Change_field==1)         //checking flag value for received data
            {
                key_detected=0;
                return;
            }
            PORTA=0x00;                 //otherwise turn of all SSD
        }
        else                            //else check Status of switches to change data 
        {
            display(ssd);
            key=read_digital_keypad(STATE_CHANGE);
            if(key==SWITCH2)            //switch2 for change the field
            {
                Change_Mode++;
                if(Change_Mode>=5)
                    Change_Mode=1;

                if(Change_Mode==1)
                {
                    ssd[0] = digit[l];
                    ssd[1] = digit[k];
                    ssd[2] = digit[j];
                    ssd[3] = digit[i] | 0x10;
                }
                else if(Change_Mode==2)
                {
                    ssd[0] = digit[l];
                    ssd[1] = digit[k];
                    ssd[2] = digit[j] | 0x10;
                    ssd[3] = digit[i];
                }
                else if(Change_Mode==3)
                {
                    ssd[0] = digit[l];
                    ssd[1] = digit[k] | 0x10;
                    ssd[2] = digit[j];
                    ssd[3] = digit[i];
                }
                else if(Change_Mode==4)
                {
                    ssd[0] = digit[l] | 0x10;
                    ssd[1] = digit[k];
                    ssd[2] = digit[j];
                    ssd[3] = digit[i];
                }
                display(ssd);   
            }

            if(key==SWITCH3 && Operation==1)        //based on switch3 & operation update data & transit to server
            {
                stock_count=((((((l*10)+k)*10)+j)*10)+i);
                write_internal_eeprom(0x00, i);          
                write_internal_eeprom(0x01, j);
                write_internal_eeprom(0x02, k);
                write_internal_eeprom(0x03, l);
                key_detected=1;
                Change_field=0;
                can_transmit();
                ssd[3] = T;
                ssd[2] = FIVE;
                ssd[1] = UNDERSCORE;
                ssd[0] = U;
                return;
            }
            else if(key==SWITCH3 && Operation==2)
            {
                Product_id=((((((l*10)+k)*10)+j)*10)+i);
                write_internal_eeprom(0x04, i);          
                write_internal_eeprom(0x05, j);
                write_internal_eeprom(0x06, k);
                write_internal_eeprom(0x07, l);
                key_detected=1;
                Change_field=0;
                can_transmit();
                ssd[3] = T;
                ssd[2] = FIVE;
                ssd[1] = UNDERSCORE;
                ssd[0] = U;
                return;
            }

            if(key==SWITCH1 && Change_Mode==1)      //switch1 for increment the values
            {
                i++;
                if(i>=10)
                    i=0;
                ssd[0] = digit[l];
                ssd[1] = digit[k];
                ssd[2] = digit[j];
                ssd[3] = digit[i] | 0x10;
            }
            else if(key==SWITCH1 && Change_Mode==2)
            {
                j++;
                if(j>=10)
                    j=0;
                ssd[0] = digit[l];
                ssd[1] = digit[k];
                ssd[2] = digit[j] | 0x10;
                ssd[3] = digit[i];
            }
            else if(key==SWITCH1 && Change_Mode==3)
            {
                k++;
                if(k>=10)
                    k=0;
                ssd[0] = digit[l];
                ssd[1] = digit[k] | 0x10;
                ssd[2] = digit[j];
                ssd[3] = digit[i];
            }
            else if(key==SWITCH1 && Change_Mode==4)
            {
                l++;
                if(l>=10)
                    l=0;
                ssd[0] = digit[l] | 0x10;
                ssd[1] = digit[k];
                ssd[2] = digit[j];
                ssd[3] = digit[i];
            }
        }
    }
}
/*Function for configuration set*/
static void init_config(void)
{
    PEIE= 1;                //interrupt enable 
	ADCON1 = 0x0F;

	TRISB6 = 0;
	TRISB0 = 1;
    
    TRISC = TRISC | INPUT_PINS;
    
	init_external_interrupt();          //function call for interrupt configuration set
    init_ssd_control();                 //function call for SSD configuration set
    init_can();                         //function call for CAN bus configuration set
    //Product_id=;
	GIE = 1;                            //enable global interrupt enable

    /*Initial value assigning to the SSD*/
    ssd[3] = T;
    ssd[2] = FIVE;
    ssd[1] = UNDERSCORE;
    ssd[0] = U;
    /*Read values from EEPROM*/
    Product_id=(read_internal_eeprom(0x04))+(read_internal_eeprom(0x05)*10)+(read_internal_eeprom(0x06)*100)+(read_internal_eeprom(0x07)*1000);
    stock_count=(read_internal_eeprom(0x00))+(read_internal_eeprom(0x01)*10)+(read_internal_eeprom(0x02)*100)+(read_internal_eeprom(0x03)*1000);
}
/*Main function*/
void main(void)
{
	unsigned int Change_Flag=1;

	init_config();                  //function call to set configuration
    
	while (1)                       //continuous loop
	{
        if(can_receive() || Flag1==1)       //check any data is received or not
        {
            Flag1=0;                //Set flag's & read received P_ID value
            Change_field=1;
            int temp_Product_id=((((((can_payload[D4]*10)+can_payload[D5])*10)+can_payload[D6])*10)+can_payload[D7]);
            if(temp_Product_id==Product_id)         //If P_ID received & stored same or not
            {
                key_detected=0;         //if same then call function
                Can_Receive_Save();
            }
            else                    //else not do anything
            {
                PORTA=0X00;
              
            }
            Change_field=0;
        }
        if(key_detected)            //check interrupt switch
        {
            PORTA=0X00;
        }
        else                        //else print data on SSD
        {
            display(ssd);
            key=read_digital_keypad(STATE_CHANGE);          //check switch status
            if(key==SWITCH3)        //switch3 for change the field
            {
                Change_Flag++;
                if(Change_Flag==2)
                {
                    ssd[3] = D;
                    ssd[2] = ONE;
                    ssd[1] = UNDERSCORE;
                    ssd[0] = P;
                }
                else
                {
                    Change_Flag=1;
                    ssd[3] = T;
                    ssd[2] = FIVE;
                    ssd[1] = UNDERSCORE;
                    ssd[0] = U;
                }
            }
            else if(key==SWITCH2)               //switch2 for change field of data inc/dec
            {
                if(Change_Flag==1)
                {
                    User_Stock();
                    for(unsigned int delay=200; delay--;);
                }
                else
                {
                    Product_ID();
                    for(unsigned int delay=200; delay--;);
                }
            }
        }
        
	}
}







