#ifndef EXTERNAL_INTERRUPT_H
#define EXTERNAL_INTERRUPT_H 

void init_external_interrupt(void);

#endif
