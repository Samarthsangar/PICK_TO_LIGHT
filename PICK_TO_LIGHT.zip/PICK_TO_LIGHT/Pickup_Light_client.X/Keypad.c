#include <xc.h>
#include "Keypad.h"

/*Function to check digital keypad switches*/
unsigned char read_digital_keypad(unsigned char detection_type)
{
	static unsigned char once = 1;
    
    for(int delay=0; delay<=200; delay++);      //make some delay to avoid bouncing effect
    
	if (detection_type == STATE_CHANGE)
	{
		if (((KEY_PORT & INPUT_PINS) != ALL_RELEASED) && once)
		{
			once = 0;

			return (KEY_PORT & INPUT_PINS);                         //return switch pressed value
		}
		else if ((KEY_PORT & INPUT_PINS) == ALL_RELEASED)
		{
			once = 1;
		}
	}
	else if (detection_type == LEVEL)                   //for level triggering
	{
		return (KEY_PORT & INPUT_PINS);
	}

	return 0xFF;
}