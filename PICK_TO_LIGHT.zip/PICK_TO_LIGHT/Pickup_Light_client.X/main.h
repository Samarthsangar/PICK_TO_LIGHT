#ifndef MAIN_H
#define MAIN_H

void User_Stock();
void SSD_PRINT_DATA(int Operation);
void Product_ID();
void Can_Receive_Save();
#define ON         		1					
#define OFF			0		

#endif
